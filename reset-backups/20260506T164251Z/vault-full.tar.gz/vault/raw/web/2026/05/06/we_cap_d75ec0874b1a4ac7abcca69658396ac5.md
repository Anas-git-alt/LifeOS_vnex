---
id: cap_d75ec0874b1a4ac7abcca69658396ac5
platform: web
kind: text
captured_at: 2026-05-06T14:44:29.847022+00:00
metadata: {"owner_authenticated": true, "sensitivity": "normal"}
---

I spent 40 MAD on lunch
