---
id: cap_93390c37a92b44d697ed8bbaefbeaf56
platform: web
kind: text
captured_at: 2026-05-06T14:46:57.293022+00:00
metadata: {"owner_authenticated": true, "sensitivity": "normal"}
---

random thought: smoke test raw note
