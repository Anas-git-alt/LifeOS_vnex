---
id: cap_db6e45e9c04943bc85bf9d0ee436aeff
platform: web
kind: text
captured_at: 2026-05-06T12:05:06.677233+00:00
metadata: {"owner_authenticated": true, "sensitivity": "normal"}
---

random thought: smoke test raw note
